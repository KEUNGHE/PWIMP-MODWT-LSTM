data_divisor <- function(data, train_per = 0.5, val_per = 0.3,
                         return_test = F, normalized = T,
                         lookback, delay, step){
  data_len <- dim(data)[1]
  train_len <- round(0.5*data_len)
  val_len <- round(0.3*data_len)
  test_len <- data_len-train_len-val_len-delay-lookback
  
  if(normalized){
    mean <- apply(data[1:(train_len),],2,mean)
    sd <- apply(data[1:(train_len),],2,sd)
    data <- scale(data,center = mean,scale = sd)
  }
  
  #training dataset
  train_feature <- array(0,dim = c(train_len,ceiling(lookback/step),dim(data)[2]))
  train_target <- array(0,dim = train_len)
  for(i in 1:train_len){
    train_feature[i,,] <- as.matrix(data[seq(i,i+lookback-1,length.out = lookback/step),])
    train_target[[i]] <- data[i+lookback+delay-1,"DO"]
  }
  
  #validation dataset
  val_feature <- array(0,dim = c(val_len,ceiling(lookback/step),dim(data)[2]))
  val_target <- array(0,dim = val_len)
  for(i in (train_len+1):(train_len+val_len)){
    val_feature[i-train_len,,] <- as.matrix(data[seq(i,i+lookback-1,length.out = lookback/step),])
    val_target[[i-train_len]] <- data[i+lookback+delay-1,"DO"]
  }
  
  data_list <- list(train_feature = train_feature, train_target = train_target,
                    val_feature = val_feature, val_target = val_target,
                    Mean = mean, Sd = sd)
  
  if(return_test){
    #testing dataset
    test_feature <- array(0,dim = c(test_len,ceiling(lookback/step),dim(data)[2]))
    test_target <- array(0,dim = test_len)
    for(i in (train_len+val_len+1):(train_len+val_len+test_len)){
      test_feature[i-train_len-val_len,,] <- as.matrix(data[seq(i,i+lookback-1,length.out = lookback/step),])
      test_target[[i-train_len-val_len]] <- data[i+lookback+delay-1,"DO"]
    }
    data_list <- list(train_feature = train_feature, train_target = train_target,
                      val_feature = val_feature, val_target = val_target,
                      test_feature = test_feature, test_target = test_target,
                      Mean = mean, Sd = sd)
  }
  
  return(data_list)
  
}

LSTM_Model <- function(lookback, num_features, Hidden_1, Hidden_2){
  
  input <- layer_input(shape = c(NULL,lookback,num_features))
  output <- input %>% layer_lstm(units = Hidden_1,return_sequences = T) %>% 
    layer_normalization() %>% 
    layer_lstm(units = Hidden_2) %>% 
    layer_dense(units = 1)
  
  lstm_model <- keras_model(input,output)
  
  lstm_model %>% compile(
    optimizer = "rmsprop",
    loss = "mae"
  )
  
  return(lstm_model)
}