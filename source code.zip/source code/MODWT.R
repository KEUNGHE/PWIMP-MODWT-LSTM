library(wavelets)
#Perform the PWIMP with mice by inputing data segment P_i
pwimp_C9 <- copy_C9
alpha <- 4
beta <- 1
for(i in 1:(length(cut_point)-1)){
  na_length <- cut_point[i+1]-cut_point[i]
  to_imp <- copy_C9[seq(na_index[cut_point[i]]-alpha*na_length,
                        na_index[cut_point[i+1]]+1+beta*na_length),]
  pwimp_i <- mice(to_imp,method = "rf",
                  printFlag = F,m=3)
  for(j in 1:4){
    pwimp_C9[rownames(pwimp_i$imp[[j]]),j] <- (pwimp_i$imp[[j]][,1]+
      pwimp_i$imp[[j]][,2]+pwimp_i$imp[[j]][,3])/3
  }
}

#Perform the GLIMP with mice by inputing the whole dataset
glimp_C9 <- copy_C9
glimp <- mice(glimp_C9,method = "rf",
              printFlag = F,m=3)
for(j in 1:4){
  glimp_C9[rownames(glimp$imp[[j]]),j] <- (glimp$imp[[j]][,1]+
    glimp$imp[[j]][,2]+glimp$imp[[j]][,3])/3
}

#Before now. two complete datasets have been generated, namely pwimp_C9 and glimp_C9

#Then, generate 4 datasets based on pwimp_C9 and glimp_C9 by introducing or not introducing MODWT
library(wavelets)
#PWIMP-MODWT
pwimp_modwt_C9 <- pwimp_C9
for(i in 1:4){
  ywd <- modwt(pwimp_modwt_C9[,i],n.levels=12)
  fico <- ywd@W[[12]]
  sigma <- mad(fico)
  utj <- sigma*sqrt(2*log(40171))/7
  for(j in 1:12){
    ywd_w <- ywd@W[[j]]
    ywd_w[which(abs(ywd_w[,1])<utj),1] <- 0
    ywd@W[[j]] <- ywd_w
  }
  iywd <- imodwt(ywd)
  pwimp_modwt_C9[,i] <- iywd
}

#GLIMP-MODWT
glimp_modwt_C9 <- glimp_C9
for(i in 1:4){
  ywd <- modwt(glimp_modwt_C9[,i],n.levels=12)
  fico <- ywd@W[[12]]
  sigma <- mad(fico)
  utj <- sigma*sqrt(2*log(40171))/7
  for(j in 1:12){
    ywd_w <- ywd@W[[j]]
    ywd_w[which(abs(ywd_w[,1])<utj),1] <- 0
    ywd@W[[j]] <- ywd_w
  }
  iywd <- imodwt(ywd)
  glimp_modwt_C9[,i] <- iywd
}

#calculate the value of indicators
Indicator_MODWT <- list()
model <- c("pwimp","glimp")
for(i in 1:2){
  modwt_C9 <- get(paste0(model[i],"_modwt_C9"))
  unmodwt_C9 <- get(paste0(model[i],"_C9"))
  for (k in 1:4){
    rsn <- 10*log(sum(modwt_C9[,k]^2)/
                    sum((modwt_C9[,k]-unmodwt_C9[,k])^2))
    esn <- sum(modwt_C9[,k]^2)/sum(unmodwt_C9[,k]^2)
    cc <- sum((modwt_C9[,k]-mean(modwt_C9[,k]))*(unmodwt_C9[,k]-mean(unmodwt_C9[,k])))/
      sqrt(sum((modwt_C9[,k]-mean(unmodwt_C9[,k]))^2)*sum((unmodwt_C9[,k]-mean(unmodwt_C9[,k]))^2))
    Indicator_MODWT[[model[i]]][[colnames(pwimp_modwt_C9)[k]]][["Rsn"]] <- rsn
    Indicator_MODWT[[model[i]]][[colnames(pwimp_modwt_C9)[k]]][["Esn"]] <- esn
    Indicator_MODWT[[model[i]]][[colnames(pwimp_modwt_C9)[k]]][["CC"]] <- cc
  }
}
