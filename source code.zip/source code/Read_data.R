#relative data path
data_path <- "lois_continuous.csv"
ori_data <- read.csv(data_path)

colnames(ori_data) <- ori_data[1,]
ori_data <- ori_data[-1,]

#Delete unneeded columns
ori_data <- ori_data[,c(-1,-3,-9)]
colnames(ori_data) <- c("id","time","pH","Cd25","DO","temp")

#Separate data from different sites
len_id <- table(ori_data[,1])
id_names <- names(len_id)
for(i in 1:length(id_names)){
  ex_data <- ori_data[which(ori_data[,"id"]==id_names[i]),]
  assign(id_names[i],ex_data[,-1])
}
rm(ex_data)
for(i in 1:length(id_names)){
  transfer <- get(id_names[i])
  for(j in 2:ncol(transfer)){
    transfer[,j] <- as.numeric(transfer[,j])
  }
  assign(id_names[i],transfer)
}

#Select station C9
to_rm <- ls()
rm(list = to_rm[-c(which(to_rm=="model_gmdh"),which(to_rm=="C9"))])

#Converting time columns to time type data
time <- strptime(C9[,1],format = "%d/%m/%Y %H:%M")
C9[,1] <- data.frame(time=time)

#fill the missing data with NA
tc <- 0
iter <- dim(C9)[1]
for(k in 2:iter){
d_t <- difftime(C9[k+tc,"time"],C9[k+tc-1,"time"],units = "mins")
d_t <- as.numeric(d_t)
if(d_t/30>1){
    fill <- d_t/30-1
    fill_df <- data.frame()
    for(l in 1:fill){
        tt <- C9[k+tc-1,1]+1800*l
        fill_m <- data.frame(tt,NA,NA,NA,NA)
        fill_df <- rbind(fill_df,fill_m)
      }
      colnames(fill_df) <- colnames(C9)
      C9 <- rbind(C9[1:(k+tc-1),],fill_df,C9[(k+tc):nrow(C9),])
      tc <- tc+fill
    }
}

to_rm <- ls()
rm(list = to_rm[-c(which(to_rm=="model_gmdh"),which(to_rm=="C9"))])

#check data situation and save the plot
library(mice)
library(VIM)
pdf("situation.pdf", bg = "transparent")
aggr(C9[,-1], prop = F, number = T)
dev.off()

#Calculate breakpoints for subsequent PWIMP modeling
copy_C9 <- C9[,-1]
rownames(copy_C9) <- seq(1,nrow(copy_C9))
na_index <- which(is.na(copy_C9[,"DO"]),arr.ind = T)

cut_point <- c()
for(i in 2:length(na_index)){
  if(na_index[i]-na_index[i-1]>1){
    cut_point <- c(cut_point,i)
  }
}
cut_point <- c(1,cut_point,length(na_index))
