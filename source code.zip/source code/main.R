#When "Read_data.R" and "MODWT.R" were loaded, four datasets have been generated
source("Read_data.R")
source("MODWT.R")
source("include_function.R")
#save the four datasets
write.csv(glimp_C9,"glimp.csv")
write.csv(pwimp_C9,"pwimp.csv")
write.csv(glimp_modwt_C9,"glimp_modwt.csv")
write.csv(pwimp_modwt_C9,"pwimp_modwt.csv")

library(keras)
#set the parameters
lookback <- 96
step <- 1
delay <- 6
num_epochs <- 30
batch_size <- 32
Hidden_1 <- 64
Hidden_2 <- 32
num_features <- 4

set.seed(123)

model_name <- c("GLIMP_LSTM","PWIMP_LSTM","GLIMP_MODWT_LSTM","PWIMP_MODWT_LSTM")
correspondind_data <- c("glimp_C9","pwimp_C9","glimp_modwt_C9","pwimp_modwt_C9")
#create a matrix to save the model indicators
model_indicators <- matrix(0,ncol = 18, nrow = 4)
colnames(model_indicators) <- c(paste0("Train_",c("MAE","MAPE","RMSE","CC","IA","NSC")),
                                paste0("Val_",c("MAE","MAPE","RMSE","CC","IA","NSC")),
                                paste0("Test_",c("MAE","MAPE","RMSE","CC","IA","NSC")))

rownames(model_indicators) <- model_name

for(i in 1:4){
  #get and divide the dataset
  data_C9 <- get(correspondind_data[i])
  data_C9 <- data_divisor(data_C9, train_per = 0.5, val_per = 0.3,
                                return_test = T, normalized = T,
                                lookback, delay, step)
  #build a lstm model
  lstm_model <- LSTM_Model(lookback, num_features, Hidden_1, Hidden_2)
  
  #set a callback list to record the best parameters of the LSTM model during training
  callbacks_lsit <- list(
    callback_model_checkpoint(
      filepath = paste0("best_model_",model_name[i],".h5"),   
      monitor = "val_loss",     
      save_best_only = TRUE
    ),
    callback_reduce_lr_on_plateau(
      monitor = "val_loss",
      patience = 3,
      factor = 0.5
    ),
    callback_early_stopping(
      monitor = "val_loss",
      patience = 6
    )
  )
  
  lstm_model %>% fit(
    data_C9$train_feature,data_C9$train_target,
    epochs = num_epochs,
    batch_size = batch_size,
    validation_data = list(data_C9$val_feature,data_C9$val_target),
    callbacks = callbacks_lsit
  )
  
  #calculate the indicators of each model
  lstm_model <- load_model_hdf5(paste0("best_model_",model_name[i],".h5"))
  #freeze the net parameters
  freeze_weights(lstm_model)
  
  train_pre <- lstm_model %>% predict(data_C9$train_feature) * data_C9$Sd[3] + data_C9$Mean[3]
  train_pre <- array(train_pre)
  train_ori <- data_C9$train_target * data_C9$Sd[3] + data_C9$Mean[3]
  train_mae <- mean(abs(train_pre-train_ori))
  train_mape <- mean(abs((train_pre-train_ori)/train_ori))*100
  train_rmse <- sqrt(mean((train_pre-train_ori)^2))
  train_cc <- sum((train_pre - mean(train_pre))*(train_ori - mean(train_ori)))/
    sqrt(sum((train_pre - mean(train_pre))^2)*sum((train_ori - mean(train_ori))^2))
  train_ia <- 1 - sum((train_pre - train_ori)^2)/
    sum((abs(train_pre-mean(train_ori)) + abs(train_ori-mean(train_ori)))^2)
  train_nsc <- 1 - sum((train_pre - train_ori)^2)/sum((train_ori - mean(train_ori))^2)
  
  model_indicators[model_name[i],1:6] <- c(train_mae,train_mape,train_rmse,
                                        train_cc,train_ia,train_nsc)
  
  val_pre <- lstm_model %>% predict(data_C9$val_feature) * data_C9$Sd[3] + data_C9$Mean[3]
  val_pre <- array(val_pre)
  val_ori <- data_C9$val_target * data_C9$Sd[3] + data_C9$Mean[3]
  val_mae <- mean(abs(val_pre-val_ori))
  val_mape <- mean(abs((val_pre-val_ori)/val_ori))*100
  val_rmse <- sqrt(mean((val_pre-val_ori)^2))
  val_cc <- sum((val_pre - mean(val_pre))*(val_ori - mean(val_ori)))/
    sqrt(sum((val_pre - mean(val_pre))^2)*sum((val_ori - mean(val_ori))^2))
  val_ia <- 1 - sum((val_pre - val_ori)^2)/
    sum((abs(val_pre-mean(val_ori)) + abs(val_ori-mean(val_ori)))^2)
  val_nsc <- 1 - sum((val_pre - val_ori)^2)/sum((val_ori - mean(val_ori))^2)
  
  model_indicators[model_name[i],7:12] <- c(val_mae,val_mape,val_rmse,
                                            val_cc,val_ia,val_nsc)
  
  test_pre <- lstm_model %>% predict(data_C9$test_feature) * data_C9$Sd[3] + data_C9$Mean[3]
  test_pre <- array(test_pre)
  test_ori <- data_C9$test_target * data_C9$Sd[3] + data_C9$Mean[3]
  test_mae <- mean(abs(test_pre-test_ori))
  test_mape <- mean(abs((test_pre-test_ori)/test_ori))*100
  test_rmse <- sqrt(mean((test_pre-test_ori)^2))
  test_cc <- sum((test_pre - mean(test_pre))*(test_ori - mean(test_ori)))/
    sqrt(sum((test_pre - mean(test_pre))^2)*sum((test_ori - mean(test_ori))^2))
  test_ia <- 1 - sum((test_pre - test_ori)^2)/
    sum((abs(test_pre-mean(test_ori)) + abs(test_ori-mean(test_ori)))^2)
  test_nsc <- 1 - sum((test_pre - test_ori)^2)/sum((test_ori - mean(test_ori))^2)
  
  model_indicators[model_name[i],13:18] <- c(test_mae,test_mape,test_rmse,
                                             test_cc,test_ia,test_nsc)
  
}






